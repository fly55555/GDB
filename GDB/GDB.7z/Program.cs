﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GDB
{
    static class Program
    {

        static void Test()
        {
            var text = "$T02thread:00000001;06:0000000000000000;07:90b54fe839000000;10:76360767fd7f0000;#45$T02thread:00000001;06:0000000000000000;07:90b54fe839000000;10:76360767fd7f0000;#45+$0300000000000000f071176ff0010000d8c1906ef001000000000000000000006c000000000000000400000000000000000000000000000090b54fe8390000000200000000000000030000000000000004000000000000002e000000000000003e00000000000000c0cc2667fd7f000080d1906ef0010000010000000000000076360767fd7f000097020000330000002b0000002b0000002b000000530000002b000000#6e";

            var lastd = 0;
            var index = 0;
            while (true)
            {
                index = lastd;
                index = text.IndexOf('#', index);
                if (index == -1)
                    break;
                var temp = text.Substring(lastd, index - lastd + 3);
                lastd = index + 3;
            }




            //var sp = text.Split('$');
            //var list = new List<string>();
            //foreach (var item in sp)
            //{
            //    list.Add($"${item}");
            //}

        }



        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            //Test();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
