﻿using GDB.Core.Register;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace GDB.Core
{
    public class ControlCenter
    {
        /// <summary>
        /// 
        /// </summary>
        private CommandInstance CmdInstance { get; set; }

        /// <summary>
        /// Target is halt
        /// </summary>
        public bool IsHalt { get; set; }

        /// <summary>
        /// Target halt event
        /// </summary>
        private AutoResetEvent HaltEvent { get; set; }

        /// <summary>
        /// Init
        /// </summary>
        public ControlCenter()
        {
            HaltEvent = new AutoResetEvent(false);

            CmdInstance = new CommandInstance();
            CmdInstance.OnHalt += TargetOnHalt;
            CmdInstance.Connect("", 8864);

            CmdInstance.ExecuteCommand("?");
            HaltEvent.WaitOne();

            //ReadTargetXml();
            //CmdInstance.MonitorCommand("r idtr");
        }

        /// <summary>
        /// Halt Handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TargetOnHalt(object sender, EventArgs e)
        {
            IsHalt = true;
            HaltEvent.Set();
        }

        /// <summary>
        /// 测试命令
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public string Execute(string command, bool monitor = true)
        {
            if (IsHalt == false)
                return "Machine is running. \r\n Can not execute string command.";

            var result = string.Empty;
            if (monitor)
            {
                result = CmdInstance.MonitorCommand(command).Replace("\n", "\r\n");
            }
            else
            {
                result = CmdInstance.ExecuteCommand(command).Original;
                if (command == "c" && result == "+")
                    IsHalt = false;
            }
            return result;
        }

        /// <summary>
        /// 调试修补问题用
        /// </summary>
        public void ReadTargetXml()
        {
            var xml = CmdInstance.ExecuteCommand("qXfer:features:read:target.xml:0,FFF");
            if (string.IsNullOrEmpty(xml.Original))
                return;

            var targetxml = xml.Nakedxml.Replace("xi:include", "include").DESerializer<Register_X86_64.target>();
            foreach (var item in targetxml.include)
            {
                if (item.href == "sse.xml")
                {
                    var childxml = CmdInstance.ExecuteCommand($"qXfer:features:read:{item.href}:0,FFF");

                    if (string.IsNullOrEmpty(childxml.Original))
                        return;

                    var ssexml = childxml.Nakedxml.Replace("xi:include", "include").DESerializer<Register_X86_64.sse>();
                }
            }
        }

        /// <summary>
        /// GetProcessorRegister
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public bool GetContext(out Register_X86_64.Context context)
        {
            var msg = CmdInstance.ExecuteCommand("g");
            var data = msg.Naked.ToBin();
            if (data.Length == 0)
            {
                context = default(Register_X86_64.Context);
                return false;
            }
            else
            {
                context = data.ToStruct<Register_X86_64.Context>();
                return true;
            }
        }

        /// <summary>
        /// Step and wait halt
        /// </summary>
        /// <returns></returns>
        public bool Step()
        {
            if (IsHalt == false)
                return false;

            CmdInstance.ExecuteCommandHalt("s:1");
            HaltEvent.WaitOne();
            return true;
        }

        /// <summary>
        /// Break and wait halt
        /// </summary>
        /// <returns></returns>
        public bool Break()
        {
            if (IsHalt == true)
                return false;

            CmdInstance.ExecuteCommandHalt("\x03");
            HaltEvent.WaitOne();
            return true;
        }

        /// <summary>
        /// Continue (no block)
        /// </summary>
        /// <returns></returns>
        public bool Continue()
        {
            if (IsHalt == false)
                return false;

            CmdInstance.ExecuteCommand("c");
            IsHalt = false;
            return true;
        }


        public bool BreakPointAdd(int type, long addr, int size)
        {
            if (IsHalt == false)
                return false;

            //Execute
            if (type == 0)
            {
                var result = CmdInstance.ExecuteCommand(string.Format("Z0,{0:X16},{1:X1}", addr, size));
                if (result.Naked.StartsWith("OK"))
                    return true;
            }

            //Write
            if (type == 1)
            {
                var result = CmdInstance.ExecuteCommand(string.Format("Z2,{0:X16},{1:X1}", addr, size));
                if (result.Naked.StartsWith("OK"))
                    return true;
            }

            //Access
            if (type == 2)
            {
                var result = CmdInstance.ExecuteCommand(string.Format("Z4,{0:X16},{1:X1}", addr, size));
                if (result.Naked.StartsWith("OK"))
                    return true;
            }

            return false;
        }


        public bool BreakPointDel(int type, long addr, int size)
        {
            if (IsHalt == false)
                return false;

            //Execute
            if (type == 0)
            {
                var result = CmdInstance.ExecuteCommand(string.Format("z0,{0:X16},{1:X1}", addr, size));
                if (result.Naked.StartsWith("OK"))
                    return true;
            }

            //Write
            if (type == 1)
            {
                var result = CmdInstance.ExecuteCommand(string.Format("z2,{0:X16},{1:X1}", addr, size));
                if (result.Naked.StartsWith("OK"))
                    return true;
            }

            //Access
            if (type == 2)
            {
                var result = CmdInstance.ExecuteCommand(string.Format("z4,{0:X16},{1:X1}", addr, size));
                if (result.Naked.StartsWith("OK"))
                    return true;
            }

            return false;
        }


        public byte[] ReadVirtual(ulong ptr, int size)
        {
            var result = CmdInstance.ExecuteCommand(string.Format("m{0:X16},{1:X3}", ptr, size));
            var data = result.Naked.ToBin();
            return data;
        }

    }
}
