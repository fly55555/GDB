﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GDB.Core
{
    public class NetController : TcpClient
    {
        public bool OpenLogger = true;

        public event EventHandler OnMessage;

        private Thread ReceiveThread { get; set; }

        public NetController()
        {
            ReceiveThread = new Thread(ReceiveThreadFunction);
            ReceiveThread.IsBackground = true;
        }

        ~NetController()
        {
            if (ReceiveThread != null && ReceiveThread.IsAlive)
                ReceiveThread.Abort();

            if (Client.Connected)
                Client.Disconnect(true);
        }


        /// <summary>
        /// Send binary protocol data to GDB
        /// </summary>
        /// <param name="package"></param>
        /// <returns></returns>
        public int SendToGDB(string package)
        {
            if (OpenLogger)
            {
                Debugger.Log(0, "", $"Send: {package} \r\n");
            }
            return Client.Send(package.ToBytes());
        }

        /// <summary>
        /// Receive single packet data 
        /// </summary>
        /// <param name="package"></param>
        private void OnReceivedSingle(string package)
        {
            if (OpenLogger)
            {
                Debugger.Log(0, "", $"Received: {package} \r\n");
            }
            OnMessage.Invoke(package, null);
        }

        /// <summary>
        /// Receive multiple packet data 
        /// </summary>
        /// <param name="package"></param>
        private void OnReceivedMultiple(string package)
        {
            if (OnMessage != null)
            {
                if (package == "+")
                {
                    OnReceivedSingle("+");
                    return;
                }

                var index = 0;
                var lastd = 0;
                while (true)
                {
                    index = lastd;
                    index = package.IndexOf('#', index);
                    if (index == -1)
                        break;

                    OnReceivedSingle(package.Substring(lastd, index - lastd + 3));
                    lastd = index + 3;
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="o"></param>
        private static void ReceiveThreadFunction(object o)
        {
            var mthis = o as NetController;
            do
            {
                var size = 4096;
                var accrualCount = 0;
                var receiveCount = 0;
                var buffer = new byte[size];

            Again:
                receiveCount = mthis.Client.Receive(buffer, accrualCount, size - accrualCount, SocketFlags.None, out SocketError error);
                accrualCount += receiveCount;

                if (receiveCount > 0)
                {
                    if (receiveCount == 1 && accrualCount == 1 && buffer[0] == '+')
                    {
                        mthis.SendToGDB("+");
                        mthis.OnReceivedMultiple("+");
                    }
                    else if (accrualCount > 3 && (buffer[0] == '+' || buffer[0] == '$') && buffer[accrualCount - 3] == '#')
                    {
                        mthis.SendToGDB("+");
                        mthis.OnReceivedMultiple(Encoding.ASCII.GetString(buffer, 0, accrualCount));
                    }
                    else if (accrualCount >= size)
                    {
                        //error package
                        throw new NotImplementedException();
                        //continue;
                    }
                    else
                    {
                        goto Again;
                    }
                }
            } while (true);
        }

        public void Stop()
        {
            ReceiveThread.Abort();
        }

        public void Start()
        {
            ReceiveThread.Start(this);
            //ReceiveThread = new Thread(() =>
            //{
            //});
            //ReceiveThread.Start();
        }
    }
}
