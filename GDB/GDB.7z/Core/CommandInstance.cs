﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GDB.Core
{
    public class GdbMessage
    {
        public string Original { get; set; }

        public string Naked
        {
            get
            {
                if (string.IsNullOrEmpty(Original))
                {
                    return "";
                }
                if (Original[0] == '+')
                {
                    return Original.Length > 4 ? Original.Substring(2, Original.Length - 5) : Original;
                }
                else if (Original[0] == '$')
                {
                    return Original.Length > 3 ? Original.Substring(1, Original.Length - 4) : Original;
                }
                else
                {
                    return "";
                }
            }
        }

        public string Nakedxml
        {
            get
            {
                return string.IsNullOrEmpty(Naked) ? "" : Naked.Substring(1);
            }
        }

        public GdbMessage(string message)
        {
            Original = message;
        }

        public List<string> GetLines(bool nake = true)
        {
            var protolines = new List<string>();
            foreach (var item in Original.Split('$'))
            {
                if (item.Length > 3)
                    protolines.Add(item.Substring(0, item.Length - 3));
            }
            return protolines;
        }
    }

    public class CommandInstance
    {
        /// <summary>
        /// 
        /// </summary>
        public event EventHandler OnHalt;

        /// <summary>
        /// Current hit processor index
        /// </summary>
        public uint HitProcessor { get; set; }

        /// <summary>
        /// Machine processor count
        /// </summary>
        public uint NumberOfProcessor { get; set; }

        /// <summary>
        /// 
        /// </summary>
        private AutoResetEvent ReceivedEvent { get; set; }

        /// <summary>
        /// 
        /// </summary>
        private AutoResetEvent CompleteEvent { get; set; }

        /// <summary>
        /// 
        /// </summary>
        private NetController GdbNetController { get; set; }

        /// <summary>
        /// 
        /// </summary>
        private ConcurrentQueue<GdbMessage> MessageQueue { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public CommandInstance()
        {
            ReceivedEvent = new AutoResetEvent(false);
            CompleteEvent = new AutoResetEvent(false);
            MessageQueue = new ConcurrentQueue<GdbMessage>();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="hostname"></param>
        /// <param name="port"></param>
        public void Connect(string hostname, int port)
        {
            GdbNetController = new NetController();
            GdbNetController.OnMessage += OnReceivedMessage;
            //GdbNetController.Client.ReceiveTimeout = -1;
            GdbNetController.Connect(hostname, port);
            GdbNetController.Start();
        }

        /// <summary>
        /// Receive Single package GDB binary protocol data
        /// </summary>
        /// <param name="o"></param>
        /// <param name="e"></param>
        private void OnReceivedMessage(object o, EventArgs e)
        {
            var message = new GdbMessage(o as string);
            MessageQueue.Enqueue(message);
            ReceivedEvent.Set();
            CompleteEvent.WaitOne();
            if (message.Naked.Length > 20 && message.Naked[0] == 'T')
            {
                if (OnHalt != null)
                {
                    OnHalt.Invoke(null, null);
                }
            }

        }

        /// <summary>
        /// Package GDB remote serial protocol 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        private string BuilderProtocol(string command)
        {
            byte sum = 0;
            for (int i = 0; i < command.Length; i++)
            {
                sum += (byte)command[i];
            }
            var builder = $"${command}#{Convert.ToString(sum, 16).PadLeft(2, '0')}";
            return builder;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private GdbMessage DequeueMessage()
        {
            GdbMessage message;
            ReceivedEvent.WaitOne();
            MessageQueue.TryDequeue(out message);
            CompleteEvent.Set();
            return message;
        }

        /// <summary>
        /// Execute command (GDB protocol)
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public GdbMessage ExecuteCommand(string command)
        {
            if (command == "?")
            {
                return ExecuteCommandHalt(command);
            }
            else
            {
                return ExecuteCommandNoHalt(command);
            }
            //GdbNetController.SendToGDB(BuilderProtocol(command));
            //return DequeueMessage();
        }

        public GdbMessage ExecuteCommandNoHalt(string command)
        {
            GdbNetController.SendToGDB(BuilderProtocol(command));
            GdbMessage item;
            do
            {
                item = DequeueMessage();
            } while (item.Naked[0] == 'T');
            return item;
        }

        public GdbMessage ExecuteCommandHalt(string command)
        {
            GdbNetController.SendToGDB(BuilderProtocol(command));
            GdbMessage item;
            do
            {
                item = DequeueMessage();
            } while (item.Naked[0] != 'T');
            return item;
        }

        /// <summary>
        /// Execute monitor command (GDB protocol)
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public string MonitorCommand(string command)
        {
            var cmdStr = BuilderProtocol($"qRcmd,{command.ToBytes().ToHex()}");
            GdbNetController.SendToGDB(cmdStr);
            GdbMessage message;
            var list = new List<GdbMessage>();
            do
            {
                message = DequeueMessage();
                list.Add(message);
            } while (message.Naked != "OK");

            var protolines = new List<string>();
            foreach (var item in list)
            {
                //filter "OK" message
                if (item.Naked != "OK")
                {
                    protolines.Add(item.Naked.Substring(1, item.Naked.Length - 1));
                }
            }
            var result = "";
            var xlines = string.Join("", protolines);
            if (!string.IsNullOrEmpty(xlines))
            {
                result = xlines.ToBin().ToTextA();
            }

            return result;
        }
    }
}
