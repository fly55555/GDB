﻿using GDB.Core;
using GDB.Core.Disassembly;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GDB
{
    public partial class Form1 : Form
    {
        ControlCenter debuggerCtrl { get; set; }

        public Form1()
        {
            InitializeComponent();
            DoubleBufferedListView(listView_Registers, true);
            DoubleBufferedListView(listView_Disassembly, true);
        }

        public void DoubleBufferedListView(ListView listView, bool flag)
        {
            Type type = listView.GetType();
            System.Reflection.PropertyInfo pi = type.GetProperty("DoubleBuffered",
                System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            pi.SetValue(listView, flag, null);
        }


        private void TestSum()
        {
            var command = "qXfer:threads:read::0,100";

            byte sum = 0;
            for (int i = 0; i < command.Length; i++)
            {
                sum += (byte)command[i];
            }
            var builder = $"${command}#{Convert.ToString(sum, 16).PadLeft(2, '0')}";
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            TestSum();
            debuggerCtrl = new ControlCenter();
            ActionUpdate();
            KeyStateUpdate();
        }


        private void ShowContext()
        {
            var context = new Core.Register.Register_X86_64.Context();
            if (!debuggerCtrl.GetContext(out context))
                return;

            var array = Core.Register.Register_X86_64.GetArray(context);

            var orgItems = listView_Registers.Items;
            if (orgItems.Count > 0)
            {
                for (int i = 0; i < Core.Register.Register_X86_64.NameArray.Length; i++)
                {
                    var currentName = Core.Register.Register_X86_64.NameArray[i];
                    orgItems[currentName].UseItemStyleForSubItems = true;
                    orgItems[currentName].SubItems[1].ForeColor = Color.Black;
                    if (orgItems[currentName].SubItems[1].Text != string.Format("{0:X16}", array[i]))
                    {
                        orgItems[currentName].UseItemStyleForSubItems = false;
                        orgItems[currentName].SubItems[1].ForeColor = Color.Red;
                    }
                    orgItems[currentName].SubItems[1].Text = string.Format("{0:X16}", array[i]);
                }
            }
            else
            {
                for (int i = 0; i < Core.Register.Register_X86_64.NameArray.Length; i++)
                {
                    var currentName = Core.Register.Register_X86_64.NameArray[i];
                    orgItems.Add(currentName, currentName, currentName).SubItems.Add(string.Format("{0:X16}", array[i]));
                }
            }

        }

        private void ShowDisassembly()
        {
            var context = new Core.Register.Register_X86_64.Context();
            if (!debuggerCtrl.GetContext(out context))
                return;
            var binaryCode = debuggerCtrl.ReadVirtual(context.rip, 128);

            var instructions = X86_64_Disassembly.DisassemblyCodeIced64(binaryCode, (long)context.rip);
            var orgItems = listView_Disassembly.Items;
            orgItems.Clear();
            foreach (var item in instructions)
            {
                if (orgItems.Count > 20) break;

                var addrStr = string.Format("{0:X16}", item.IP);
                var opCodes = binaryCode.SkipTake((int)(item.IP - context.rip), item.Length);
                var byteStr = string.Format("{0}", BitConverter.ToString(opCodes).Replace("-", " "));
                var currentItem = orgItems.Add(addrStr, addrStr, addrStr);
                currentItem.SubItems.Add(byteStr);
                currentItem.SubItems.Add(item.ToString());

                if (item.IP == context.rip)
                    currentItem.BackColor = Color.Yellow;
            }
        }

        private void ActionUpdate()
        {
            if (debuggerCtrl.IsHalt)
            {
                ShowContext();
                ShowDisassembly();
            }
        }

        private void KeyStateUpdate()
        {
            if (debuggerCtrl.IsHalt)
            {
                stepIntoToolStripMenuItem.Enabled = true;
                stepOverToolStripMenuItem.Enabled = true;
                runToolStripMenuItem1.Enabled = true;

                breakToolStripMenuItem.Enabled = false;
            }
            else
            {
                stepIntoToolStripMenuItem.Enabled = false;
                stepOverToolStripMenuItem.Enabled = false;
                runToolStripMenuItem1.Enabled = false;

                breakToolStripMenuItem.Enabled = true;
            }
        }

        private void runToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (listView_Disassembly.Items != null && listView_Disassembly.Items.Count > 0)
                listView_Disassembly.Items[0].BackColor = Color.White;

            debuggerCtrl.Continue();
            KeyStateUpdate();
        }

        /// <summary>
        /// Step Over
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void stepToolStripMenuItem_Click(object sender, EventArgs e)
        {
            debuggerCtrl.Step();
            ActionUpdate();
            KeyStateUpdate();
        }

        /// <summary>
        /// Break
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void breakToolStripMenuItem_Click(object sender, EventArgs e)
        {
            debuggerCtrl.Break();
            ActionUpdate();
            KeyStateUpdate();
        }

        /// <summary>
        /// Step Into
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void stepOverToolStripMenuItem_Click(object sender, EventArgs e)
        {
            debuggerCtrl.Step();
            ActionUpdate();
            KeyStateUpdate();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void executeTillReturnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KeyStateUpdate();
        }

        private void ExecuteTest_Click(object sender, EventArgs e)
        {
            textBox_GDBOutput.Text = debuggerCtrl.Execute(textBox_GDBCommand.Text);
        }

        private void UpdateBreakPoint_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow item in dataGridView_BreakPoint.Rows)
            {
                if (item.Cells.Count == 3)
                {
                    if (!string.IsNullOrEmpty((string)item.Cells[0].Value) &&
                        !string.IsNullOrEmpty((string)item.Cells[1].Value) &&
                        !string.IsNullOrEmpty((string)item.Cells[2].Value))
                    {
                        var addr = (string)item.Cells[0].Value;
                        var type = (string)item.Cells[1].Value;
                        var open = (string)item.Cells[2].Value;
                        if (open == "1")
                        {
                            debuggerCtrl.BreakPointAdd(Convert.ToInt32(type), Convert.ToInt64(addr, 16), 1);
                        }
                        else
                        {
                            debuggerCtrl.BreakPointDel(Convert.ToInt32(type), Convert.ToInt64(addr, 16), 1);
                        }
                    }
                }
            }
        }
    }
}
